import React, { useEffect, useRef, useState } from "react";
import { FilesetResolver, ImageSegmenter } from "../../vision_bundle"; // Adjust the import path as needed

interface SmartWebcamProps {
  maskColor: Array<number>;
  stream: MediaStream | null;
}

const SmartWebcam: React.FC<SmartWebcamProps> = ({ maskColor, stream }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvas1Ref = useRef<HTMLCanvasElement | null>(null);
  const canvas1aRef = useRef<HTMLCanvasElement | null>(null);
  const canvas2Ref = useRef<HTMLCanvasElement | null>(null);
  const [imageSegmenter, setImageSegmenter] = useState<InstanceType<
    typeof ImageSegmenter
  > | null>(null);
  const [webcamRunning, setWebcamRunning] = useState(false);
  const [lastWebcamTime, setLastWebcamTime] = useState(-1);

  useEffect(() => {
    const initialize = async () => {
      const segmenter = await createImageSegmenter();
      setImageSegmenter(segmenter);
    };

    initialize().then(() => {
      if (stream) {
        console.log("Stream is available, starting webcam...");
        startWebcam(); // Start the webcam after the segmenter is ready
      } else {
        console.error("Stream is not available");
      }
    });
  }, [stream]);

  useEffect(() => {
    if (webcamRunning) {
      predictWebcam(); // Re-run segmentation whenever maskColor changes
    }
  }, [maskColor]);

  const createImageSegmenter = async (): Promise<InstanceType<
    typeof ImageSegmenter
  > | null> => {
    try {
      console.log("Creating image segmenter...");
      const vision = await FilesetResolver.forVisionTasks("./wasm");
      const segmenter = await ImageSegmenter.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: "./hair_segmenter.tflite",
          delegate: "CPU",
        },
        runningMode: "VIDEO",
        outputCategoryMask: true,
        outputConfidenceMasks: true,
      });
      console.log("Image segmenter created successfully.");
      return segmenter;
    } catch (error) {
      console.error("Failed to create image segmenter:", error);
      return null;
    }
  };

  const startWebcam = async () => {
    try {
      console.log("Starting webcam...");
      if (videoRef.current && stream) {
        videoRef.current.srcObject = stream;

        videoRef.current.onloadedmetadata = () => {
          videoRef.current
            ?.play()
            .then(() => {
              console.log("Video started, running predictWebcam...");
              setWebcamRunning(true);
              predictWebcam(); // Start segmentation only after the video is playing
            })
            .catch((error) => {
              console.error("Error playing video:", error);
            });
        };
      } else {
        console.error("Video element or stream is not available.");
      }
    } catch (error) {
      console.error("Error starting webcam:", error);
    }
  };

  const predictWebcam = async () => {
    // Wait until imageSegmenter and videoRef are both ready
    if (!imageSegmenter || !videoRef.current) {
      //console.log("Waiting for segmenter and video...");
      //requestAnimationFrame(predictWebcam);
      return; // Exit early if not ready
    }
    //console.log("Predicting webcam...");

    const video = videoRef.current;
    const canvas1 = canvas1Ref.current;
    const canvas1a = canvas1aRef.current;
    const canvas2 = canvas2Ref.current;

    if (!canvas1 || !canvas1a || !canvas2) {
      console.error("One or more canvases are not available.");
      return;
    }

    const canvasCtx = canvas1.getContext("2d", { willReadFrequently: true });
    const canvasCtxa = canvas1a.getContext("2d", { willReadFrequently: true });
    const canvasCtx2 = canvas2.getContext("2d", { willReadFrequently: true });

    /*if (video.currentTime === lastWebcamTime) {
      if (webcamRunning) {
        window.requestAnimationFrame(predictWebcam);
      }
      return;
    } */

    setLastWebcamTime(video.currentTime);

    // Clear and draw the video frame onto the secondary canvas
    canvasCtx?.clearRect(0, 0, video.videoWidth, video.videoHeight);
    canvasCtx2?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);

    const startTimeMs = performance.now();
    await imageSegmenter.segmentForVideo(video, startTimeMs, callbackForVideo);
  };

  const callbackForVideo = (result: any) => {
    const video = videoRef.current;
    const canvas1 = canvas1Ref.current;
    const canvas1a = canvas1aRef.current;
    const canvas2 = canvas2Ref.current;

    const canvasCtx = canvas1?.getContext("2d");
    const canvasCtxa = canvas1a?.getContext("2d");
    const canvasCtx2 = canvas2?.getContext("2d");

    if (webcamRunning && canvas1 && canvas2 && video) {
      // Display canvases
      canvas1.style.display = "flex";
      canvas2.style.display = "flex";

      let imageData = canvasCtx?.getImageData(
        0,
        0,
        video.videoWidth,
        video.videoHeight
      ).data;
      const mask = result.categoryMask.getAsFloat32Array();

      let j = 0;
      for (let i = 0; i < mask.length; ++i) {
        const maskVal = Math.round(mask[i] * 255.0);
        if (!maskVal) {
          j += 4;
        } else {
          const [r, g, b, a] = maskColor;
          imageData![j] = r + imageData![j];
          imageData![j + 1] = g + imageData![j + 1];
          imageData![j + 2] = b + imageData![j + 2];
          imageData![j + 3] = a;
          j += 4;
        }
      }
      const uint8Array = new Uint8ClampedArray(imageData!.buffer);
      const dataNew = new ImageData(
        uint8Array,
        video.videoWidth,
        video.videoHeight
      );

      canvasCtx!.imageSmoothingEnabled = true;
      canvasCtx?.putImageData(dataNew, 0, 0);
      canvasCtxa?.putImageData(dataNew, 0, 0);

      window.requestAnimationFrame(predictWebcam);
    } else {
      if (canvas1) canvas1.style.display = "none";
      if (canvas2) canvas2.style.display = "none";
    }
  };

  return (
    <div className="smart-webcam" id="smart-webcam" style={{ display: "flex" }}>
      <canvas
        id="canvas1"
        ref={canvas1Ref}
        width="640"
        height="480"
        style={{
          position: "relative",
          zIndex: 100,
          opacity: 0.75,
          filter: "blur(10px)",
          mixBlendMode: "soft-light",
        }}
      ></canvas>
      <canvas
        id="canvas1a"
        ref={canvas1aRef}
        width="640"
        height="480"
        style={{
          position: "absolute",
          zIndex: 99,
          opacity: 0.75,
          filter: "blur(10px)",
          mixBlendMode: "soft-light",
        }}
      ></canvas>
      <div
        id="draggableBorderV"
        style={{ display: "none" }}
        className="draggable-border"
      ></div>
      <canvas
        id="canvas2"
        ref={canvas2Ref}
        width="640"
        height="480"
        style={{ display: "none", position: "absolute", zIndex: 1 }}
      ></canvas>
      <video
        id="webcam"
        ref={videoRef}
        width="640"
        height="480"
        playsInline
        style={{ display: "none", zIndex: -1 }}
      ></video>
    </div>
  );
};

export default SmartWebcam;
